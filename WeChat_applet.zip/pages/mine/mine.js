Page({
    data: {
        entrance: [
            [
                {title: '我的名片', icon: '../../image/mine/user_icon1.png'},
                {title: '我的方案', icon: '../../image/mine/user_icon2.png'},
                {title: '我的活动', icon: '../../image/mine/user_icon4.png'}
            ], [
                {title: '我的名片', icon: '../../image/mine/user_icon1.png'},
                {title: '我的方案', icon: '../../image/mine/user_icon2.png'}
            ]
        ]
    },
    onShow() {
        
    }
})