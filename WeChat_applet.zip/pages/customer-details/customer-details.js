Page({
    data: {
        tabData: [
            {type: "1", name: "线索"},
            {type: "2", name: "资料"}
        ],
        tabType: 1,
        pull: {
            isLoading: false,
            loading: '../../image/common/pull_refresh.gif',
            pullText: '正在加载'
        },
        push: {
            isLoading: false,
            loading: '../../image/common/pull_refresh.gif',
            pullText: '-上拉加载更多-'
        },
    },
    homeTabChange(e) {
        this.setData({ tabType: e.detail.itemData.type })
    },
    refresh(e) {
        console.log('刷新', e)
        this.setData({
            'pull.isLoading': true,
            'pull.loading': '../../image/common/pull_refresh.gif',
            'pull.pullText': '正在加载',
        })
        setTimeout(() => {
            this.setData({
                'pull.loading': '../../image/common/finish.png',
                'pull.pullText': '刷新完成'
            })
        }, 4000)
        setTimeout(() => {
            this.setData({
                'pull.isLoading': false,
            })
            console.log('+++++ 刷新完成 +++++')
        }, 6000)
    },
    toload(e) {
        console.log('加载', e),
        this.setData({
            'push.isLoading': true,
            'push.pullText': '正在加载',
            'push.loading': '../../image/common/pull_refresh.gif',
        })
        // if (this.data.clueData.length < 30) {
            setTimeout(() => {
                // let data = this.data.clueData.concat([
                // 	{createTime: '2019-11-12 16:33'},
                //     {createTime: '2019-11-12 14:55'},
                // ])
                this.setData({
                    // clueData: data,
                    'push.isLoading': false,
                    'push.pullText': '- 上拉加载更多 -',
                    'push.loading': '../../image/common/finish.png',
                })
                console.log('===== 加载完成 =====')
            }, 2000)
        // }
    },
    onUnload({ next }) {
        console.log(next)
        showModal({
            success(confirm){     
                next(true)
            }
        })  
    }
})