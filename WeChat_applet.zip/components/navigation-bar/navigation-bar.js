Component({
  data: {},
  properties: {},
  methods: {}
})